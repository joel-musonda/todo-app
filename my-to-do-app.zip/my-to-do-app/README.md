# My To-Do app

A Pen created on CodePen.io. Original URL: [https://codepen.io/Joel-Musonda/pen/OJqPLzN](https://codepen.io/Joel-Musonda/pen/OJqPLzN).

A React-ready starter template.